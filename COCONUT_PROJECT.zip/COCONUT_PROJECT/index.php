<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="./styles/style.css">
</head>
<body>
    <div class="mainContainer">
      <div class="navBar">
        <div class="logo">
          <h3><a href="#">Trust Coconut</a></h3>
        </div>
        <div class="signUpDiv">
          <a class="logIn" href="login.php">Log In</a>
        </div>
      </div>
      <div class="titleText">
      <div class="mainText">
        <h1>we Give The Best Taste,</h1>
      </div>
      <div class="subText">
        <h4>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto nam aut nesciunt, laborum expedita maxime 
          suscipit nostrum iure culpa exercitationem nemo! Officiis minima unde cumque id, delectus dolores itaque eveniet!</h4>
      </div>
    </div>
    <div class="poster">
      <img src="./img/Dingtalk_20210508082935.jpg" alt="poster" />
    </div>
      <!-- <div class="thirdContainer">
        <div class="cardContainer">
          <div class="infoCards">
            <img src="#" alt="card" />
            <h4>Legal Services</h4>
            <p>Minimum Requirements in Purchase. Zero Documentation.</p>
            <a href="#">Learn more.</a>
          </div>
        </div>
      </div> -->
      <footer>
        <div class="footerDivs">
          <p>&copy;2022 Coconut, Inc</p>
          <a href="#">Terms & Conditions</a>
        </div>
        <div class="footerDivs">
          <h5 class="contact"><a href="#">Contact Us</a></h5>
          <p>+94777334477</p>
          <p>coconut@info.com</p>
        </div>
        <div class="footerDivs">
          <h3>Trust Coconut</h3>
        </div>
        <div class="footerDivs"></div>
      </footer>
    </div>
</body>
</html>